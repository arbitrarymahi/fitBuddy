import 'package:flutter/material.dart';
import 'package:flare_flutter/flare_actor.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'FitBddy',
      home: StartScreen(),
    );
  }
}

class StartScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      body: Column(children: <Widget>[
        Text('his'),
        Container(
          width: 500,
          height: 500,
          child: FlareActor('assets/RopeSkippingChicken.flr',
              animation: "Untitled", fit: BoxFit.cover),
        ),
      ]),
    );
  }
}
